# Sheep Gem — Landing Page

A static landing page for the Sheep Gem feng shui stone business, with a lightweight, no-backend CMS for editing content.

## Preview

Double-click `index.html` to open it in your browser. No server or install step needed.

## Structure

```
index.html              Landing page markup
admin.html               Content editor (the "CMS")
css/style.css            Landing page styles
css/admin.css            Editor styles
js/main.js               Renders content into index.html
js/admin.js              Powers the editor form
content/site-content.js  All editable site content (text, prices, links)
```

## Editing content

Two ways:

1. **Visual editor** — open `admin.html`. Edit any field on the left and watch the live preview on the right update instantly (toggle Desktop/Mobile to check responsiveness). When you're happy with it, click "Download updated site-content.js" and replace `content/site-content.js` with the downloaded file.
2. **Direct edit** — open `content/site-content.js` in any text editor and change values directly. Reload `index.html`.

Either way, no build step, database, or server is required — everything is plain files.

## Next steps

This version is a static site (HTML/CSS/JS) so it renders immediately with zero setup. It was built as a fast first look while a sandbox issue blocked reading the original architecture doc and prior project zip. Natural next steps once that's resolved:

- Reconcile this build against the original architecture/schema (stack choice, real CMS backend, product catalog structure).
- If a dynamic CMS is wanted (multi-user editing, image uploads, a proper admin login), migrate to something like Next.js + a headless CMS (Sanity, Contentful, or a self-hosted option).
- Add real product photography and copy review.
- Wire the newsletter form and contact form to an actual email service.
