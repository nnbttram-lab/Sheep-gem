import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import Faq from "@/components/Faq";
import ConsultationCTA from "@/components/ConsultationCTA";
import { getPublishedFaq } from "@/services/faq";
import { getLocale } from "@/lib/i18n/get-locale";
import { getDictionary } from "@/lib/i18n/dictionaries";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "FAQ — Sheep Gem",
};

export default async function FaqPage() {
  const locale = await getLocale();
  const dict = getDictionary(locale);
  const items = await getPublishedFaq();

  return (
    <>
      <Navbar dict={dict} locale={locale} />
      <main>
        <Faq items={items} dict={dict} />
      </main>
      <ConsultationCTA dict={dict} />
      <Footer dict={dict} />
    </>
  );
}
