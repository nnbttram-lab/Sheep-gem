import { requireAdmin } from "@/cms/lib/require-admin";
import { getSiteSettings } from "@/services/settings";
import { updateSiteSettings } from "@/cms/actions/settings";

export default async function SettingsPage() {
  await requireAdmin();
  const settings = await getSiteSettings();

  return (
    <div>
      <h1 className="font-display text-3xl italic text-ink">Settings</h1>

      <form action={updateSiteSettings} className="mt-8 max-w-xl space-y-5">
        <div>
          <label className="mb-1 block font-mono text-[10px] uppercase tracking-widest2 text-ink/50">
            Brand name
          </label>
          <input name="brand_name" defaultValue={settings.brand_name} className="input" />
        </div>

        <div>
          <label className="mb-1 block font-mono text-[10px] uppercase tracking-widest2 text-ink/50">
            Tagline — English (shown in the hero for EN visitors)
          </label>
          <input name="tagline_en" defaultValue={settings.tagline_en} className="input" />
        </div>

        <div>
          <label className="mb-1 block font-mono text-[10px] uppercase tracking-widest2 text-ink/50">
            Tagline — Vietnamese (shown in the hero for VI visitors)
          </label>
          <input name="tagline_vi" defaultValue={settings.tagline_vi} className="input" />
        </div>

        <button
          type="submit"
          className="bg-jade px-6 py-3 font-mono text-xs uppercase tracking-widest2 text-stone-paper hover:bg-jade-deep"
        >
          Save settings
        </button>
      </form>
    </div>
  );
}
