import { requireAdmin } from "@/cms/lib/require-admin";
import { createClient } from "@/lib/supabase/server";

async function getCounts() {
  const supabase = await createClient();
  const [products, collections, testimonials, faq] = await Promise.all([
    supabase.from("products").select("id", { count: "exact", head: true }),
    supabase.from("collections").select("id", { count: "exact", head: true }),
    supabase
      .from("testimonials")
      .select("id", { count: "exact", head: true }),
    supabase.from("faq").select("id", { count: "exact", head: true }),
  ]);

  return {
    products: products.count ?? 0,
    collections: collections.count ?? 0,
    testimonials: testimonials.count ?? 0,
    faq: faq.count ?? 0,
  };
}

export default async function DashboardPage() {
  await requireAdmin();
  const counts = await getCounts();

  const cards = [
    { label: "Products", value: counts.products },
    { label: "Collections", value: counts.collections },
    { label: "Testimonials", value: counts.testimonials },
    { label: "FAQ entries", value: counts.faq },
  ];

  return (
    <div>
      <h1 className="font-display text-3xl italic text-ink">Dashboard</h1>
      <p className="mt-1 text-ink/60">Overview of your published content.</p>

      <div className="mt-8 grid gap-4 sm:grid-cols-4">
        {cards.map((c) => (
          <div
            key={c.label}
            className="border border-stone-line bg-stone-paper p-6"
          >
            <p className="font-mono text-[10px] uppercase tracking-widest2 text-ink/50">
              {c.label}
            </p>
            <p className="mt-2 font-display text-4xl italic text-ink">
              {c.value}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
}
