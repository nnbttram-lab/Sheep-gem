import { requireAdmin } from "@/cms/lib/require-admin";
import { createFaq } from "@/cms/actions/faq";
import FaqForm from "@/cms/components/FaqForm";

export default async function NewFaqPage() {
  await requireAdmin();
  return (
    <div>
      <h1 className="font-display text-3xl italic text-ink">New FAQ entry</h1>
      <div className="mt-8">
        <FaqForm action={createFaq} />
      </div>
    </div>
  );
}
