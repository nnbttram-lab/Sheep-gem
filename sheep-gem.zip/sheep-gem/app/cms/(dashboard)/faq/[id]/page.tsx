import { notFound } from "next/navigation";
import { requireAdmin } from "@/cms/lib/require-admin";
import { createClient } from "@/lib/supabase/server";
import { updateFaq } from "@/cms/actions/faq";
import FaqForm from "@/cms/components/FaqForm";

export default async function EditFaqPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  await requireAdmin();
  const { id } = await params;
  const supabase = await createClient();
  const { data: item } = await supabase
    .from("faq")
    .select("*")
    .eq("id", id)
    .maybeSingle();

  if (!item) notFound();

  return (
    <div>
      <h1 className="font-display text-3xl italic text-ink">Edit FAQ entry</h1>
      <div className="mt-8">
        <FaqForm action={updateFaq.bind(null, id)} item={item} />
      </div>
    </div>
  );
}
