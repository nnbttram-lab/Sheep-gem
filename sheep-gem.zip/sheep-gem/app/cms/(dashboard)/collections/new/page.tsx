import { requireAdmin } from "@/cms/lib/require-admin";
import { createCollection } from "@/cms/actions/collections";
import CollectionForm from "@/cms/components/CollectionForm";

export default async function NewCollectionPage() {
  await requireAdmin();
  return (
    <div>
      <h1 className="font-display text-3xl italic text-ink">New collection</h1>
      <div className="mt-8">
        <CollectionForm action={createCollection} />
      </div>
    </div>
  );
}
