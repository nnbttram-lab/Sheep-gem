import { notFound } from "next/navigation";
import { requireAdmin } from "@/cms/lib/require-admin";
import { createClient } from "@/lib/supabase/server";
import { updateCollection } from "@/cms/actions/collections";
import CollectionForm from "@/cms/components/CollectionForm";

export default async function EditCollectionPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  await requireAdmin();
  const { id } = await params;
  const supabase = await createClient();
  const { data: collection } = await supabase
    .from("collections")
    .select("*")
    .eq("id", id)
    .maybeSingle();

  if (!collection) notFound();

  return (
    <div>
      <h1 className="font-display text-3xl italic text-ink">
        Edit {collection.name}
      </h1>
      <div className="mt-8">
        <CollectionForm
          action={updateCollection.bind(null, id)}
          collection={collection}
        />
      </div>
    </div>
  );
}
