import Link from "next/link";
import { requireAdmin } from "@/cms/lib/require-admin";
import { createClient } from "@/lib/supabase/server";
import { deleteCollection } from "@/cms/actions/collections";

export default async function CollectionsListPage() {
  await requireAdmin();
  const supabase = await createClient();
  const { data: collections } = await supabase
    .from("collections")
    .select("*")
    .order("sort_order");

  return (
    <div>
      <div className="flex items-center justify-between">
        <h1 className="font-display text-3xl italic text-ink">Collections</h1>
        <Link
          href="/cms/collections/new"
          className="bg-jade px-4 py-2 font-mono text-xs uppercase tracking-widest2 text-stone-paper hover:bg-jade-deep"
        >
          + New collection
        </Link>
      </div>

      <table className="mt-8 w-full border border-stone-line bg-stone-paper text-left">
        <thead>
          <tr className="border-b border-stone-line font-mono text-[10px] uppercase tracking-widest2 text-ink/50">
            <th className="p-3">Name</th>
            <th className="p-3">Status</th>
            <th className="p-3"></th>
          </tr>
        </thead>
        <tbody>
          {collections?.map((c) => (
            <tr key={c.id} className="border-b border-stone-line last:border-0">
              <td className="p-3 text-ink">{c.name}</td>
              <td className="p-3">
                <span
                  className={`font-mono text-[10px] uppercase tracking-widest2 ${
                    c.status === "published" ? "text-jade-deep" : "text-ink/40"
                  }`}
                >
                  {c.status}
                </span>
              </td>
              <td className="p-3 text-right">
                <Link
                  href={`/cms/collections/${c.id}`}
                  className="mr-4 font-mono text-xs uppercase tracking-widest2 text-ink/60 hover:text-jade-deep"
                >
                  Edit
                </Link>
                <form action={deleteCollection.bind(null, c.id)} className="inline">
                  <button
                    type="submit"
                    className="font-mono text-xs uppercase tracking-widest2 text-amethyst hover:text-amethyst-soft"
                  >
                    Delete
                  </button>
                </form>
              </td>
            </tr>
          ))}
          {(!collections || collections.length === 0) && (
            <tr>
              <td colSpan={3} className="p-6 text-center text-ink/50">
                No collections yet.
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}
