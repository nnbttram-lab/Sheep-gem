import Link from "next/link";
import { requireAdmin } from "@/cms/lib/require-admin";
import { createClient } from "@/lib/supabase/server";
import { deleteTestimonial } from "@/cms/actions/testimonials";

export default async function TestimonialsListPage() {
  await requireAdmin();
  const supabase = await createClient();
  const { data: testimonials } = await supabase
    .from("testimonials")
    .select("*")
    .order("sort_order");

  return (
    <div>
      <div className="flex items-center justify-between">
        <h1 className="font-display text-3xl italic text-ink">Testimonials</h1>
        <Link
          href="/cms/testimonials/new"
          className="bg-jade px-4 py-2 font-mono text-xs uppercase tracking-widest2 text-stone-paper hover:bg-jade-deep"
        >
          + New testimonial
        </Link>
      </div>

      <table className="mt-8 w-full border border-stone-line bg-stone-paper text-left">
        <thead>
          <tr className="border-b border-stone-line font-mono text-[10px] uppercase tracking-widest2 text-ink/50">
            <th className="p-3">Author</th>
            <th className="p-3">Quote</th>
            <th className="p-3">Status</th>
            <th className="p-3"></th>
          </tr>
        </thead>
        <tbody>
          {testimonials?.map((t) => (
            <tr key={t.id} className="border-b border-stone-line last:border-0">
              <td className="p-3 text-ink">{t.author_name}</td>
              <td className="max-w-xs truncate p-3 text-ink/70">{t.quote}</td>
              <td className="p-3">
                <span
                  className={`font-mono text-[10px] uppercase tracking-widest2 ${
                    t.status === "published" ? "text-jade-deep" : "text-ink/40"
                  }`}
                >
                  {t.status}
                </span>
              </td>
              <td className="p-3 text-right">
                <Link
                  href={`/cms/testimonials/${t.id}`}
                  className="mr-4 font-mono text-xs uppercase tracking-widest2 text-ink/60 hover:text-jade-deep"
                >
                  Edit
                </Link>
                <form action={deleteTestimonial.bind(null, t.id)} className="inline">
                  <button
                    type="submit"
                    className="font-mono text-xs uppercase tracking-widest2 text-amethyst hover:text-amethyst-soft"
                  >
                    Delete
                  </button>
                </form>
              </td>
            </tr>
          ))}
          {(!testimonials || testimonials.length === 0) && (
            <tr>
              <td colSpan={4} className="p-6 text-center text-ink/50">
                No testimonials yet.
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}
