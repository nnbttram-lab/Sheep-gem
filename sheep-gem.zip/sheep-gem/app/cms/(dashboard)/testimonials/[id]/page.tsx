import { notFound } from "next/navigation";
import { requireAdmin } from "@/cms/lib/require-admin";
import { createClient } from "@/lib/supabase/server";
import { updateTestimonial } from "@/cms/actions/testimonials";
import TestimonialForm from "@/cms/components/TestimonialForm";

export default async function EditTestimonialPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  await requireAdmin();
  const { id } = await params;
  const supabase = await createClient();
  const { data: testimonial } = await supabase
    .from("testimonials")
    .select("*")
    .eq("id", id)
    .maybeSingle();

  if (!testimonial) notFound();

  return (
    <div>
      <h1 className="font-display text-3xl italic text-ink">
        Edit testimonial
      </h1>
      <div className="mt-8">
        <TestimonialForm
          action={updateTestimonial.bind(null, id)}
          testimonial={testimonial}
        />
      </div>
    </div>
  );
}
