import { requireAdmin } from "@/cms/lib/require-admin";
import { createTestimonial } from "@/cms/actions/testimonials";
import TestimonialForm from "@/cms/components/TestimonialForm";

export default async function NewTestimonialPage() {
  await requireAdmin();
  return (
    <div>
      <h1 className="font-display text-3xl italic text-ink">New testimonial</h1>
      <div className="mt-8">
        <TestimonialForm action={createTestimonial} />
      </div>
    </div>
  );
}
