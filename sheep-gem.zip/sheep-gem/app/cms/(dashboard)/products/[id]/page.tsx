import { notFound } from "next/navigation";
import { requireAdmin } from "@/cms/lib/require-admin";
import { createClient } from "@/lib/supabase/server";
import { updateProduct } from "@/cms/actions/products";
import ProductForm from "@/cms/components/ProductForm";

export default async function EditProductPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  await requireAdmin();
  const { id } = await params;
  const supabase = await createClient();

  const [{ data: product }, { data: collections }] = await Promise.all([
    supabase.from("products").select("*").eq("id", id).maybeSingle(),
    supabase.from("collections").select("*").order("sort_order"),
  ]);

  if (!product) notFound();

  return (
    <div>
      <h1 className="font-display text-3xl italic text-ink">
        Edit {product.name}
      </h1>
      <div className="mt-8">
        <ProductForm
          action={updateProduct.bind(null, id)}
          product={product}
          collections={collections ?? []}
        />
      </div>
    </div>
  );
}
