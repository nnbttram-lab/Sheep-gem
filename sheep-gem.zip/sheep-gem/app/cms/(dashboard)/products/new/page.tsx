import { requireAdmin } from "@/cms/lib/require-admin";
import { createClient } from "@/lib/supabase/server";
import { createProduct } from "@/cms/actions/products";
import ProductForm from "@/cms/components/ProductForm";

export default async function NewProductPage() {
  await requireAdmin();
  const supabase = await createClient();
  const { data: collections } = await supabase
    .from("collections")
    .select("*")
    .order("sort_order");

  return (
    <div>
      <h1 className="font-display text-3xl italic text-ink">New product</h1>
      <div className="mt-8">
        <ProductForm action={createProduct} collections={collections ?? []} />
      </div>
    </div>
  );
}
