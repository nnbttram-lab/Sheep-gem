import Link from "next/link";
import { requireAdmin } from "@/cms/lib/require-admin";
import { createClient } from "@/lib/supabase/server";
import { deleteProduct } from "@/cms/actions/products";
import type { Product } from "@/types";

export default async function ProductsListPage() {
  await requireAdmin();
  const supabase = await createClient();
  const { data: products } = await supabase
    .from("products")
    .select("*, collection:collections(*)")
    .order("created_at", { ascending: false });

  return (
    <div>
      <div className="flex items-center justify-between">
        <h1 className="font-display text-3xl italic text-ink">Products</h1>
        <Link
          href="/cms/products/new"
          className="bg-jade px-4 py-2 font-mono text-xs uppercase tracking-widest2 text-stone-paper hover:bg-jade-deep"
        >
          + New product
        </Link>
      </div>

      <table className="mt-8 w-full border border-stone-line bg-stone-paper text-left">
        <thead>
          <tr className="border-b border-stone-line font-mono text-[10px] uppercase tracking-widest2 text-ink/50">
            <th className="p-3">Name</th>
            <th className="p-3">Collection</th>
            <th className="p-3">Price</th>
            <th className="p-3">Status</th>
            <th className="p-3"></th>
          </tr>
        </thead>
        <tbody>
          {(products as Product[] | null)?.map((p) => (
            <tr key={p.id} className="border-b border-stone-line last:border-0">
              <td className="p-3 text-ink">{p.name}</td>
              <td className="p-3 text-ink/70">{p.collection?.name ?? "—"}</td>
              <td className="p-3 font-mono text-ink/70">
                ${p.price.toFixed(2)}
              </td>
              <td className="p-3">
                <span
                  className={`font-mono text-[10px] uppercase tracking-widest2 ${
                    p.status === "published" ? "text-jade-deep" : "text-ink/40"
                  }`}
                >
                  {p.status}
                </span>
              </td>
              <td className="p-3 text-right">
                <Link
                  href={`/cms/products/${p.id}`}
                  className="mr-4 font-mono text-xs uppercase tracking-widest2 text-ink/60 hover:text-jade-deep"
                >
                  Edit
                </Link>
                <form
                  action={deleteProduct.bind(null, p.id)}
                  className="inline"
                >
                  <button
                    type="submit"
                    className="font-mono text-xs uppercase tracking-widest2 text-amethyst hover:text-amethyst-soft"
                  >
                    Delete
                  </button>
                </form>
              </td>
            </tr>
          ))}
          {(!products || products.length === 0) && (
            <tr>
              <td colSpan={5} className="p-6 text-center text-ink/50">
                No products yet.
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}
