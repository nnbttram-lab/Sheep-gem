import Sidebar from "@/cms/components/Sidebar";

export default function CmsLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className="flex min-h-screen bg-stone">
      <Sidebar />
      <div className="flex-1 overflow-y-auto p-10">{children}</div>
    </div>
  );
}
