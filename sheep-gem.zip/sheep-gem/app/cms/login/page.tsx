import { signIn } from "@/cms/actions/auth";

export default async function LoginPage({
  searchParams,
}: {
  searchParams: Promise<{ error?: string }>;
}) {
  const { error } = await searchParams;

  return (
    <main className="flex min-h-screen items-center justify-center bg-stone px-6">
      <div className="w-full max-w-sm border border-stone-line bg-stone-paper p-8">
        <p className="font-display text-3xl italic text-ink">Sheep Gem</p>
        <p className="mt-1 font-mono text-[10px] uppercase tracking-widest2 text-ink/40">
          CMS sign in
        </p>

        {error && (
          <p className="mt-4 border border-amethyst bg-amethyst/10 p-3 text-sm text-amethyst">
            {error}
          </p>
        )}

        <form action={signIn} className="mt-6 space-y-4">
          <div>
            <label className="font-mono text-[10px] uppercase tracking-widest2 text-ink/50">
              Email
            </label>
            <input
              type="email"
              name="email"
              required
              className="mt-1 w-full border border-stone-line bg-stone-paper px-3 py-2 text-ink outline-none focus:border-jade"
            />
          </div>
          <div>
            <label className="font-mono text-[10px] uppercase tracking-widest2 text-ink/50">
              Password
            </label>
            <input
              type="password"
              name="password"
              required
              className="mt-1 w-full border border-stone-line bg-stone-paper px-3 py-2 text-ink outline-none focus:border-jade"
            />
          </div>
          <button
            type="submit"
            className="w-full bg-jade py-2 font-mono text-xs uppercase tracking-widest2 text-stone-paper hover:bg-jade-deep"
          >
            Sign in
          </button>
        </form>
      </div>
    </main>
  );
}
