import type { Metadata } from "next";
import { Instrument_Serif, Karla, IBM_Plex_Mono } from "next/font/google";
import "./globals.css";

const displayFont = Instrument_Serif({
  subsets: ["latin"],
  weight: ["400"],
  style: ["normal", "italic"],
  variable: "--font-display",
});

const bodyFont = Karla({
  subsets: ["latin"],
  weight: ["400", "500", "600"],
  variable: "--font-body",
});

const monoFont = IBM_Plex_Mono({
  subsets: ["latin"],
  weight: ["400", "500"],
  variable: "--font-mono",
});

export const metadata: Metadata = {
  title: "Sheep Gem — Find the stone that finds you",
  description:
    "Fengshui-guided gemstones, chosen with meaning. Explore collections, learn each stone's story, and talk with Sheep to find yours.",
  metadataBase: new URL("https://sheepgem.com"),
  openGraph: {
    title: "Sheep Gem",
    description: "Find the stone that finds you.",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body
        className={`${displayFont.variable} ${bodyFont.variable} ${monoFont.variable} font-body antialiased`}
      >
        {children}
      </body>
    </html>
  );
}
