import Image from "next/image";
import { notFound } from "next/navigation";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import ConsultationCTA from "@/components/ConsultationCTA";
import { getProductBySlug } from "@/services/products";
import { getLocale } from "@/lib/i18n/get-locale";
import { getDictionary } from "@/lib/i18n/dictionaries";
import type { Metadata } from "next";

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const product = await getProductBySlug(slug);
  if (!product) return {};
  return {
    title: `${product.name} — Sheep Gem`,
    description: product.meaning ?? product.description ?? undefined,
  };
}

export default async function ProductPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const [product, locale] = await Promise.all([
    getProductBySlug(slug),
    getLocale(),
  ]);
  const dict = getDictionary(locale);

  if (!product) notFound();

  return (
    <>
      <Navbar dict={dict} locale={locale} />
      <main className="px-6 py-16">
        <div className="mx-auto grid max-w-6xl gap-12 sm:grid-cols-2">
          <div className="relative aspect-[4/5] overflow-hidden bg-stone-paper">
            {product.images?.[0] ? (
              <Image
                src={product.images[0]}
                alt={product.name}
                fill
                className="object-cover"
                sizes="(min-width: 640px) 50vw, 100vw"
                priority
              />
            ) : (
              <div className="flex h-full items-center justify-center font-mono text-xs uppercase tracking-widest2 text-ink/40">
                {dict.product.noImage}
              </div>
            )}
          </div>

          <div>
            {product.collection && (
              <span className="font-mono text-xs uppercase tracking-widest2 text-brass">
                {product.collection.name}
              </span>
            )}
            <h1 className="mt-3 font-display text-4xl italic text-ink">
              {product.name}
            </h1>
            <p className="mt-3 font-mono text-lg text-ink">
              ${product.price.toFixed(2)}
            </p>

            {/* Certificate-style spec block */}
            <dl className="mt-8 space-y-3 border border-stone-line bg-stone-paper p-6 font-mono text-sm">
              {product.gemstone && (
                <div className="flex justify-between border-b border-dashed border-stone-line pb-2">
                  <dt className="uppercase tracking-widest2 text-ink/50">
                    {dict.product.gemstone}
                  </dt>
                  <dd className="text-ink">{product.gemstone}</dd>
                </div>
              )}
              {product.materials && (
                <div className="flex justify-between border-b border-dashed border-stone-line pb-2">
                  <dt className="uppercase tracking-widest2 text-ink/50">
                    {dict.product.materials}
                  </dt>
                  <dd className="text-ink">{product.materials}</dd>
                </div>
              )}
            </dl>

            {product.meaning && (
              <div className="mt-8">
                <h2 className="font-display text-2xl italic text-ink">
                  {dict.product.meaning}
                </h2>
                <p className="mt-2 text-ink/75">{product.meaning}</p>
              </div>
            )}

            {product.story && (
              <div className="mt-8">
                <h2 className="font-display text-2xl italic text-ink">
                  {dict.product.story}
                </h2>
                <p className="mt-2 text-ink/75">{product.story}</p>
              </div>
            )}

            {product.description && (
              <div className="mt-8">
                <h2 className="font-display text-2xl italic text-ink">
                  {dict.product.description}
                </h2>
                <p className="mt-2 text-ink/75">{product.description}</p>
              </div>
            )}
          </div>
        </div>
      </main>
      <ConsultationCTA productName={product.name} dict={dict} />
      <Footer dict={dict} />
    </>
  );
}
