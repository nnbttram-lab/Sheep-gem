import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import GemCard from "@/components/GemCard";
import { getPublishedCollections } from "@/services/collections";
import { getPublishedProducts } from "@/services/products";
import { getLocale } from "@/lib/i18n/get-locale";
import { getDictionary } from "@/lib/i18n/dictionaries";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Collections — Sheep Gem",
};

export default async function CollectionsPage() {
  const locale = await getLocale();
  const dict = getDictionary(locale);

  const [collections, products] = await Promise.all([
    getPublishedCollections(),
    getPublishedProducts(),
  ]);

  return (
    <>
      <Navbar dict={dict} locale={locale} />
      <main className="px-6 py-16">
        <div className="mx-auto max-w-6xl">
          <span className="font-mono text-xs uppercase tracking-widest2 text-brass">
            {dict.collectionsPage.eyebrow}
          </span>
          <h1 className="mt-3 font-display text-5xl italic text-ink">
            {dict.collectionsPage.title}
          </h1>

          {collections.length === 0 && (
            <p className="mt-6 text-ink/60">{dict.collectionsSection.empty}</p>
          )}

          {collections.map((collection) => {
            const items = products.filter(
              (p) => p.collection_id === collection.id
            );
            if (items.length === 0) return null;

            return (
              <section key={collection.id} id={collection.slug} className="mt-16 scroll-mt-24">
                <h2 className="font-display text-3xl italic text-ink">
                  {collection.name}
                </h2>
                {collection.description && (
                  <p className="mt-2 max-w-2xl text-ink/70">
                    {collection.description}
                  </p>
                )}
                <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                  {items.map((p) => (
                    <GemCard key={p.id} product={p} dict={dict} />
                  ))}
                </div>
              </section>
            );
          })}
        </div>
      </main>
      <Footer dict={dict} />
    </>
  );
}
