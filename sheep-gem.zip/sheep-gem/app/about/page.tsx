import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import About from "@/components/About";
import Philosophy from "@/components/Philosophy";
import ConsultationCTA from "@/components/ConsultationCTA";
import { getLocale } from "@/lib/i18n/get-locale";
import { getDictionary } from "@/lib/i18n/dictionaries";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "About — Sheep Gem",
};

export default async function AboutPage() {
  const locale = await getLocale();
  const dict = getDictionary(locale);

  return (
    <>
      <Navbar dict={dict} locale={locale} />
      <main>
        <div className="px-6 pt-16">
          <div className="mx-auto max-w-3xl text-center">
            <span className="font-mono text-xs uppercase tracking-widest2 text-brass">
              {dict.aboutPage.eyebrow}
            </span>
            <h1 className="mt-3 font-display text-5xl italic text-ink">
              {dict.aboutPage.title}
            </h1>
          </div>
        </div>
        <About dict={dict} />
        <Philosophy dict={dict} />
      </main>
      <ConsultationCTA dict={dict} />
      <Footer dict={dict} />
    </>
  );
}
