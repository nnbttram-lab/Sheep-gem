import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import About from "@/components/About";
import Philosophy from "@/components/Philosophy";
import CollectionGrid from "@/components/CollectionGrid";
import FeaturedProducts from "@/components/FeaturedProducts";
import ConsultationCTA from "@/components/ConsultationCTA";
import Testimonials from "@/components/Testimonials";
import Faq from "@/components/Faq";
import Footer from "@/components/Footer";

import { getSiteSettings, getTagline } from "@/services/settings";
import { getPublishedCollections } from "@/services/collections";
import { getFeaturedProducts } from "@/services/products";
import { getPublishedTestimonials } from "@/services/testimonials";
import { getPublishedFaq } from "@/services/faq";
import { getLocale } from "@/lib/i18n/get-locale";
import { getDictionary } from "@/lib/i18n/dictionaries";

export default async function HomePage() {
  const locale = await getLocale();
  const dict = getDictionary(locale);

  const [settings, collections, featuredProducts, testimonials, faqItems] =
    await Promise.all([
      getSiteSettings(),
      getPublishedCollections(),
      getFeaturedProducts(),
      getPublishedTestimonials(),
      getPublishedFaq(),
    ]);

  return (
    <>
      <Navbar dict={dict} locale={locale} />
      <main>
        <Hero tagline={getTagline(settings, locale)} dict={dict} />
        <About dict={dict} />
        <Philosophy dict={dict} />
        <CollectionGrid collections={collections} dict={dict} />
        <FeaturedProducts products={featuredProducts} dict={dict} />
        <ConsultationCTA dict={dict} />
        <Testimonials testimonials={testimonials} dict={dict} />
        <Faq items={faqItems} dict={dict} />
      </main>
      <Footer dict={dict} />
    </>
  );
}
