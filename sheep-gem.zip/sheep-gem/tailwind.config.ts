import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./app/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
    "./features/**/*.{ts,tsx}",
    "./cms/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        ink: "#1E1A16",
        jade: {
          DEFAULT: "#2F5D50",
          deep: "#1F3F36",
          soft: "#4A7A6B",
        },
        stone: {
          DEFAULT: "#E8E1D3",
          paper: "#F7F4EC",
          line: "#D8CFBB",
        },
        brass: {
          DEFAULT: "#B08D57",
          soft: "#C9A876",
        },
        amethyst: {
          DEFAULT: "#7B5C82",
          soft: "#9A7FA0",
        },
      },
      fontFamily: {
        display: ["var(--font-display)", "serif"],
        body: ["var(--font-body)", "sans-serif"],
        mono: ["var(--font-mono)", "monospace"],
      },
      letterSpacing: {
        widest2: "0.28em",
      },
      borderRadius: {
        seal: "2px",
      },
    },
  },
  plugins: [],
};
export default config;
