"use client";

import { useRouter } from "next/navigation";
import { useTransition } from "react";
import { LOCALE_COOKIE, type Locale } from "@/lib/i18n/locales";

export default function LanguageSwitcher({ locale }: { locale: Locale }) {
  const router = useRouter();
  const [isPending, startTransition] = useTransition();

  function switchTo(next: Locale) {
    if (next === locale) return;
    document.cookie = `${LOCALE_COOKIE}=${next}; path=/; max-age=${60 * 60 * 24 * 365}`;
    startTransition(() => router.refresh());
  }

  return (
    <div
      className="flex items-center gap-1 font-mono text-xs uppercase tracking-widest2"
      aria-label="Language"
    >
      <button
        type="button"
        onClick={() => switchTo("en")}
        disabled={isPending}
        aria-current={locale === "en"}
        className={
          locale === "en"
            ? "text-ink"
            : "text-ink/40 hover:text-ink/70"
        }
      >
        EN
      </button>
      <span className="text-ink/30">/</span>
      <button
        type="button"
        onClick={() => switchTo("vi")}
        disabled={isPending}
        aria-current={locale === "vi"}
        className={
          locale === "vi"
            ? "text-ink"
            : "text-ink/40 hover:text-ink/70"
        }
      >
        VI
      </button>
    </div>
  );
}
