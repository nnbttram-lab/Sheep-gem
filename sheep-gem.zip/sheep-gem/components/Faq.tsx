import type { FaqItem } from "@/types";
import type { Dictionary } from "@/lib/i18n/dictionaries";

export default function Faq({
  items,
  dict,
}: {
  items: FaqItem[];
  dict: Dictionary;
}) {
  if (items.length === 0) return null;

  return (
    <section className="border-b border-stone-line bg-stone-paper px-6 py-20">
      <div className="mx-auto max-w-3xl">
        <span className="font-mono text-xs uppercase tracking-widest2 text-brass">
          {dict.faq.eyebrow}
        </span>
        <h2 className="mt-3 font-display text-4xl italic text-ink">
          {dict.faq.title}
        </h2>

        <div className="mt-10 divide-y divide-stone-line border-y border-stone-line">
          {items.map((item) => (
            <details key={item.id} className="group py-5">
              <summary className="flex cursor-pointer list-none items-center justify-between font-display text-xl text-ink">
                {item.question}
                <span className="ml-4 font-mono text-brass transition-transform group-open:rotate-45">
                  +
                </span>
              </summary>
              <p className="mt-3 text-ink/70">{item.answer}</p>
            </details>
          ))}
        </div>
      </div>
    </section>
  );
}
