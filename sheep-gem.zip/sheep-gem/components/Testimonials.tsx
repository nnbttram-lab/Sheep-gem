import type { Testimonial } from "@/types";
import type { Dictionary } from "@/lib/i18n/dictionaries";

export default function Testimonials({
  testimonials,
  dict,
}: {
  testimonials: Testimonial[];
  dict: Dictionary;
}) {
  if (testimonials.length === 0) return null;

  return (
    <section className="border-b border-stone-line px-6 py-20">
      <div className="mx-auto max-w-6xl">
        <span className="font-mono text-xs uppercase tracking-widest2 text-brass">
          {dict.testimonials.eyebrow}
        </span>
        <h2 className="mt-3 font-display text-4xl italic text-ink">
          {dict.testimonials.title}
        </h2>

        <div className="mt-10 grid gap-6 sm:grid-cols-3">
          {testimonials.map((t) => (
            <blockquote
              key={t.id}
              className="border border-stone-line bg-stone-paper p-6"
            >
              <p className="text-ink/80">"{t.quote}"</p>
              <footer className="mt-4 font-mono text-[11px] uppercase tracking-widest2 text-jade-deep">
                {t.author_name}
                {t.author_location ? ` — ${t.author_location}` : ""}
              </footer>
            </blockquote>
          ))}
        </div>
      </div>
    </section>
  );
}
