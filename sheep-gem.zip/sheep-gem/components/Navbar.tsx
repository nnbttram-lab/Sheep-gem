import Link from "next/link";
import LanguageSwitcher from "./LanguageSwitcher";
import type { Dictionary } from "@/lib/i18n/dictionaries";
import type { Locale } from "@/lib/i18n/locales";

export default function Navbar({
  dict,
  locale,
}: {
  dict: Dictionary;
  locale: Locale;
}) {
  const links = [
    { href: "/collections", label: dict.nav.collections },
    { href: "/about", label: dict.nav.about },
    { href: "/faq", label: dict.nav.faq },
  ];

  return (
    <header className="sticky top-0 z-40 border-b border-stone-line bg-stone/95 backdrop-blur">
      <nav className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
        <Link href="/" className="font-display text-2xl italic text-ink">
          Sheep Gem
        </Link>
        <ul className="hidden items-center gap-8 sm:flex">
          {links.map((link) => (
            <li key={link.href}>
              <Link
                href={link.href}
                className="font-mono text-xs uppercase tracking-widest2 text-ink/70 transition-colors hover:text-jade-deep"
              >
                {link.label}
              </Link>
            </li>
          ))}
        </ul>
        <div className="flex items-center gap-5">
          <LanguageSwitcher locale={locale} />
          <Link
            href="#consultation"
            className="border border-ink px-4 py-2 font-mono text-xs uppercase tracking-widest2 text-ink transition-colors hover:bg-ink hover:text-stone-paper"
          >
            {dict.nav.talkWithSheep}
          </Link>
        </div>
      </nav>
    </header>
  );
}
