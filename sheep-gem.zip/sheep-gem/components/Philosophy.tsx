import type { Dictionary } from "@/lib/i18n/dictionaries";

export default function Philosophy({ dict }: { dict: Dictionary }) {
  return (
    <section className="border-b border-stone-line bg-stone-paper px-6 py-20">
      <div className="mx-auto max-w-6xl">
        <div className="max-w-2xl">
          <span className="font-mono text-xs uppercase tracking-widest2 text-brass">
            {dict.philosophy.eyebrow}
          </span>
          <h2 className="mt-3 font-display text-4xl italic text-ink">
            {dict.philosophy.title}
          </h2>
          <p className="mt-4 text-ink/70">{dict.philosophy.body}</p>
        </div>

        <div className="mt-12 grid gap-px overflow-hidden border border-stone-line bg-stone-line sm:grid-cols-5">
          {dict.philosophy.elements.map((el) => (
            <div key={el.name} className="bg-stone-paper p-6">
              <p className="font-mono text-[11px] uppercase tracking-widest2 text-jade-deep">
                {el.name}
              </p>
              <p className="mt-3 font-display text-2xl italic text-ink">
                {el.stone}
              </p>
              <p className="mt-2 text-sm text-ink/60">{el.trait}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
