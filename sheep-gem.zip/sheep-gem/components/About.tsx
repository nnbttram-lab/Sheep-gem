import type { Dictionary } from "@/lib/i18n/dictionaries";

export default function About({ dict }: { dict: Dictionary }) {
  return (
    <section className="border-b border-stone-line px-6 py-20">
      <div className="mx-auto grid max-w-6xl gap-10 sm:grid-cols-2">
        <div>
          <span className="font-mono text-xs uppercase tracking-widest2 text-brass">
            {dict.about.eyebrow}
          </span>
          <h2 className="mt-3 font-display text-4xl italic text-ink">
            {dict.about.title}
          </h2>
        </div>
        <p className="text-ink/75">{dict.about.body}</p>
      </div>
    </section>
  );
}
