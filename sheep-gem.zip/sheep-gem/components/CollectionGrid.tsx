import Image from "next/image";
import Link from "next/link";
import type { Collection } from "@/types";
import type { Dictionary } from "@/lib/i18n/dictionaries";

export default function CollectionGrid({
  collections,
  dict,
}: {
  collections: Collection[];
  dict: Dictionary;
}) {
  if (collections.length === 0) return null;

  return (
    <section className="border-b border-stone-line px-6 py-20">
      <div className="mx-auto max-w-6xl">
        <div className="flex items-end justify-between">
          <div>
            <span className="font-mono text-xs uppercase tracking-widest2 text-brass">
              {dict.collectionsSection.eyebrow}
            </span>
            <h2 className="mt-3 font-display text-4xl italic text-ink">
              {dict.collectionsSection.title}
            </h2>
          </div>
          <Link
            href="/collections"
            className="hidden font-mono text-xs uppercase tracking-widest2 text-ink/60 hover:text-jade-deep sm:block"
          >
            {dict.collectionsSection.viewAll}
          </Link>
        </div>

        <div className="mt-10 grid gap-6 sm:grid-cols-3">
          {collections.map((c) => (
            <Link
              key={c.id}
              href={`/collections#${c.slug}`}
              className="group relative block aspect-[3/4] overflow-hidden bg-stone-paper"
            >
              {c.cover_image ? (
                <Image
                  src={c.cover_image}
                  alt={c.name}
                  fill
                  className="object-cover transition-transform duration-700 group-hover:scale-105"
                  sizes="(min-width: 640px) 33vw, 100vw"
                />
              ) : (
                <div className="h-full w-full bg-jade/10" />
              )}
              <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-ink/80 to-transparent p-5">
                <p className="font-display text-2xl italic text-stone-paper">
                  {c.name}
                </p>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
