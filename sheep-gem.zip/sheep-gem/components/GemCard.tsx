import Image from "next/image";
import Link from "next/link";
import type { Product } from "@/types";
import type { Dictionary } from "@/lib/i18n/dictionaries";

/**
 * Signature element: each product reads like a gemological
 * appraisal card rather than a typical e-commerce tile —
 * mono-set specs (element, gemstone, meaning) framed with a
 * dashed "certificate" border and a wax-seal-style link.
 */
export default function GemCard({
  product,
  dict,
}: {
  product: Product;
  dict: Dictionary;
}) {
  const image = product.images?.[0];

  return (
    <Link
      href={`/product/${product.slug}`}
      className="group block border border-stone-line bg-stone-paper p-4 transition-colors hover:border-jade"
    >
      <div className="relative aspect-[4/5] overflow-hidden bg-stone">
        {image ? (
          <Image
            src={image}
            alt={product.name}
            fill
            className="object-cover transition-transform duration-700 group-hover:scale-105"
            sizes="(min-width: 1024px) 25vw, (min-width: 640px) 33vw, 50vw"
          />
        ) : (
          <div className="flex h-full items-center justify-center font-mono text-xs uppercase tracking-widest2 text-ink/40">
            {dict.product.noImage}
          </div>
        )}
        {product.collection && (
          <span className="absolute left-2 top-2 bg-ink/85 px-2 py-1 font-mono text-[10px] uppercase tracking-widest2 text-stone-paper">
            {product.collection.name}
          </span>
        )}
      </div>

      <div className="mt-4 seal-divider pt-3">
        <h3 className="font-display text-2xl leading-tight text-ink">
          {product.name}
        </h3>
        {product.gemstone && (
          <p className="mt-1 font-mono text-[11px] uppercase tracking-widest2 text-jade-deep">
            {product.gemstone}
          </p>
        )}
        {product.meaning && (
          <p className="mt-2 line-clamp-2 text-sm text-ink/70">
            {product.meaning}
          </p>
        )}
        <div className="mt-3 flex items-center justify-between">
          <span className="font-mono text-sm text-ink">
            ${product.price.toFixed(2)}
          </span>
          <span className="font-mono text-[11px] uppercase tracking-widest2 text-brass group-hover:text-jade-deep">
            {dict.product.view}
          </span>
        </div>
      </div>
    </Link>
  );
}
