"use client";

import { motion } from "framer-motion";
import Link from "next/link";
import type { Dictionary } from "@/lib/i18n/dictionaries";

export default function Hero({
  tagline,
  dict,
}: {
  tagline: string;
  dict: Dictionary;
}) {
  return (
    <section className="relative overflow-hidden border-b border-stone-line px-6 py-28">
      <div className="mx-auto max-w-4xl text-center">
        <motion.span
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="font-mono text-xs uppercase tracking-widest2 text-brass"
        >
          {dict.hero.eyebrow}
        </motion.span>

        <motion.h1
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.1 }}
          className="mt-6 font-display text-5xl italic leading-[1.05] text-ink sm:text-7xl"
        >
          {tagline}
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.2 }}
          className="mx-auto mt-6 max-w-xl text-base text-ink/70"
        >
          {dict.hero.subtext}
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.3 }}
          className="mt-10 flex items-center justify-center gap-4"
        >
          <Link
            href="/collections"
            className="bg-jade px-6 py-3 font-mono text-xs uppercase tracking-widest2 text-stone-paper transition-colors hover:bg-jade-deep"
          >
            {dict.hero.exploreCollections}
          </Link>
          <Link
            href="#consultation"
            className="border border-ink px-6 py-3 font-mono text-xs uppercase tracking-widest2 text-ink transition-colors hover:bg-ink hover:text-stone-paper"
          >
            {dict.hero.talkWithSheep}
          </Link>
        </motion.div>
      </div>
    </section>
  );
}
