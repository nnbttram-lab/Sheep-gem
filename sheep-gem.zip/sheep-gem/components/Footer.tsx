import Link from "next/link";
import type { Dictionary } from "@/lib/i18n/dictionaries";

export default function Footer({ dict }: { dict: Dictionary }) {
  return (
    <footer className="px-6 py-12">
      <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-6 sm:flex-row">
        <p className="font-display text-xl italic text-ink">Sheep Gem</p>
        <ul className="flex gap-6 font-mono text-xs uppercase tracking-widest2 text-ink/60">
          <li>
            <Link href="/collections" className="hover:text-jade-deep">
              {dict.nav.collections}
            </Link>
          </li>
          <li>
            <Link href="/about" className="hover:text-jade-deep">
              {dict.nav.about}
            </Link>
          </li>
          <li>
            <Link href="/faq" className="hover:text-jade-deep">
              {dict.nav.faq}
            </Link>
          </li>
        </ul>
        <p className="font-mono text-[11px] text-ink/40">
          © {new Date().getFullYear()} Sheep Gem
        </p>
      </div>
    </footer>
  );
}
