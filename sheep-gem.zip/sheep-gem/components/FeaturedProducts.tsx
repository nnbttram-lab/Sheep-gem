import GemCard from "./GemCard";
import type { Product } from "@/types";
import type { Dictionary } from "@/lib/i18n/dictionaries";

export default function FeaturedProducts({
  products,
  dict,
}: {
  products: Product[];
  dict: Dictionary;
}) {
  if (products.length === 0) return null;

  return (
    <section className="border-b border-stone-line px-6 py-20">
      <div className="mx-auto max-w-6xl">
        <span className="font-mono text-xs uppercase tracking-widest2 text-brass">
          {dict.featured.eyebrow}
        </span>
        <h2 className="mt-3 font-display text-4xl italic text-ink">
          {dict.featured.title}
        </h2>

        <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {products.map((p) => (
            <GemCard key={p.id} product={p} dict={dict} />
          ))}
        </div>
      </div>
    </section>
  );
}
