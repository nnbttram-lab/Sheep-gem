import { getInstagramLink, getMessengerLink, getPrefilledMessage } from "@/lib/consultation";
import type { Dictionary } from "@/lib/i18n/dictionaries";

export default function ConsultationCTA({
  productName,
  dict,
}: {
  productName?: string;
  dict: Dictionary;
}) {
  const message = getPrefilledMessage(productName);

  return (
    <section
      id="consultation"
      className="border-b border-stone-line bg-jade-deep px-6 py-20 text-stone-paper"
    >
      <div className="mx-auto max-w-2xl text-center">
        <span className="font-mono text-xs uppercase tracking-widest2 text-brass-soft">
          {dict.consultation.eyebrow}
        </span>
        <h2 className="mt-3 font-display text-4xl italic">
          {dict.consultation.title}
        </h2>
        <p className="mx-auto mt-4 max-w-md text-stone-paper/80">
          {dict.consultation.subtext}
        </p>

        {/* Prefilled message — shown so it can be copied into Instagram DMs,
            since Instagram doesn't support prefilling text via URL. */}
        <div className="mx-auto mt-6 max-w-md border border-dashed border-stone-paper/40 bg-stone-paper/10 p-4 text-left">
          <p className="font-mono text-[10px] uppercase tracking-widest2 text-brass-soft">
            {dict.consultation.yourMessage}
          </p>
          <p className="mt-1 text-sm text-stone-paper/90">{message}</p>
        </div>

        <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
          <a
            href={getInstagramLink(productName)}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full bg-stone-paper px-6 py-3 text-center font-mono text-xs uppercase tracking-widest2 text-jade-deep transition-colors hover:bg-brass hover:text-stone-paper sm:w-auto"
          >
            {dict.consultation.instagramBtn}
          </a>
          <a
            href={getMessengerLink(productName)}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full border border-stone-paper px-6 py-3 text-center font-mono text-xs uppercase tracking-widest2 text-stone-paper transition-colors hover:bg-stone-paper hover:text-jade-deep sm:w-auto"
          >
            {dict.consultation.facebookBtn}
          </a>
        </div>
      </div>
    </section>
  );
}
