import type { FaqItem } from "@/types";

export default function FaqForm({
  action,
  item,
}: {
  action: (formData: FormData) => void;
  item?: FaqItem;
}) {
  return (
    <form action={action} className="max-w-xl space-y-5">
      <div>
        <label className="mb-1 block font-mono text-[10px] uppercase tracking-widest2 text-ink/50">
          Question
        </label>
        <input name="question" defaultValue={item?.question} required className="input" />
      </div>

      <div>
        <label className="mb-1 block font-mono text-[10px] uppercase tracking-widest2 text-ink/50">
          Answer
        </label>
        <textarea name="answer" defaultValue={item?.answer} rows={4} required className="input" />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="mb-1 block font-mono text-[10px] uppercase tracking-widest2 text-ink/50">
            Sort order
          </label>
          <input name="sort_order" type="number" defaultValue={item?.sort_order ?? 0} className="input" />
        </div>
        <div>
          <label className="mb-1 block font-mono text-[10px] uppercase tracking-widest2 text-ink/50">
            Status
          </label>
          <select name="status" defaultValue={item?.status ?? "draft"} className="input">
            <option value="draft">Draft</option>
            <option value="published">Published</option>
          </select>
        </div>
      </div>

      <button
        type="submit"
        className="bg-jade px-6 py-3 font-mono text-xs uppercase tracking-widest2 text-stone-paper hover:bg-jade-deep"
      >
        Save FAQ entry
      </button>
    </form>
  );
}
