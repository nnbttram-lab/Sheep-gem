import ImageUploader from "./ImageUploader";
import type { Collection } from "@/types";

export default function CollectionForm({
  action,
  collection,
}: {
  action: (formData: FormData) => void;
  collection?: Collection;
}) {
  return (
    <form action={action} className="max-w-xl space-y-5">
      <div>
        <label className="mb-1 block font-mono text-[10px] uppercase tracking-widest2 text-ink/50">
          Name
        </label>
        <input name="name" defaultValue={collection?.name} required className="input" />
      </div>

      <div>
        <label className="mb-1 block font-mono text-[10px] uppercase tracking-widest2 text-ink/50">
          Slug (leave blank to auto-generate)
        </label>
        <input name="slug" defaultValue={collection?.slug} className="input" />
      </div>

      <div>
        <label className="mb-1 block font-mono text-[10px] uppercase tracking-widest2 text-ink/50">
          Description
        </label>
        <textarea
          name="description"
          defaultValue={collection?.description ?? ""}
          rows={3}
          className="input"
        />
      </div>

      <div>
        <label className="mb-1 block font-mono text-[10px] uppercase tracking-widest2 text-ink/50">
          Cover image
        </label>
        <ImageUploader name="cover_image" defaultValue={collection?.cover_image ?? ""} />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="mb-1 block font-mono text-[10px] uppercase tracking-widest2 text-ink/50">
            Sort order
          </label>
          <input
            name="sort_order"
            type="number"
            defaultValue={collection?.sort_order ?? 0}
            className="input"
          />
        </div>
        <div>
          <label className="mb-1 block font-mono text-[10px] uppercase tracking-widest2 text-ink/50">
            Status
          </label>
          <select name="status" defaultValue={collection?.status ?? "draft"} className="input">
            <option value="draft">Draft</option>
            <option value="published">Published</option>
          </select>
        </div>
      </div>

      <button
        type="submit"
        className="bg-jade px-6 py-3 font-mono text-xs uppercase tracking-widest2 text-stone-paper hover:bg-jade-deep"
      >
        Save collection
      </button>
    </form>
  );
}
