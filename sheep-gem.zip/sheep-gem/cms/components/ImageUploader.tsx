"use client";

import { useState } from "react";
import { createClient } from "@/lib/supabase/client";

const BUCKET = "media";

export default function ImageUploader({
  name,
  defaultValue,
}: {
  name: string;
  defaultValue?: string;
}) {
  const [urls, setUrls] = useState<string[]>(
    defaultValue ? defaultValue.split(",").filter(Boolean) : []
  );
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleFiles(files: FileList | null) {
    if (!files || files.length === 0) return;
    setUploading(true);
    setError(null);

    const supabase = createClient();
    const uploaded: string[] = [];

    for (const file of Array.from(files)) {
      const path = `products/${Date.now()}-${file.name}`;
      const { error: uploadError } = await supabase.storage
        .from(BUCKET)
        .upload(path, file);

      if (uploadError) {
        setError(uploadError.message);
        continue;
      }

      const { data } = supabase.storage.from(BUCKET).getPublicUrl(path);
      uploaded.push(data.publicUrl);
    }

    setUrls((prev) => [...prev, ...uploaded]);
    setUploading(false);
  }

  function removeAt(index: number) {
    setUrls((prev) => prev.filter((_, i) => i !== index));
  }

  return (
    <div>
      {/* Hidden input carries the comma-separated URL list to the server action */}
      <input type="hidden" name={name} value={urls.join(",")} />

      <input
        type="file"
        accept="image/*"
        multiple
        onChange={(e) => handleFiles(e.target.files)}
        className="block w-full font-mono text-xs text-ink/70"
      />
      {uploading && (
        <p className="mt-2 font-mono text-xs text-ink/50">Uploading…</p>
      )}
      {error && (
        <p className="mt-2 font-mono text-xs text-amethyst">{error}</p>
      )}

      {urls.length > 0 && (
        <div className="mt-3 flex flex-wrap gap-3">
          {urls.map((url, i) => (
            <div key={url} className="relative h-20 w-20 overflow-hidden border border-stone-line">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={url} alt="" className="h-full w-full object-cover" />
              <button
                type="button"
                onClick={() => removeAt(i)}
                className="absolute right-0 top-0 bg-ink/80 px-1 text-[10px] text-stone-paper"
              >
                ×
              </button>
            </div>
          ))}
        </div>
      )}
      <p className="mt-2 font-mono text-[10px] text-ink/40">
        Requires a public "media" bucket in Supabase Storage.
      </p>
    </div>
  );
}
