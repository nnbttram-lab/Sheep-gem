import type { Testimonial } from "@/types";

export default function TestimonialForm({
  action,
  testimonial,
}: {
  action: (formData: FormData) => void;
  testimonial?: Testimonial;
}) {
  return (
    <form action={action} className="max-w-xl space-y-5">
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="mb-1 block font-mono text-[10px] uppercase tracking-widest2 text-ink/50">
            Author name
          </label>
          <input name="author_name" defaultValue={testimonial?.author_name} required className="input" />
        </div>
        <div>
          <label className="mb-1 block font-mono text-[10px] uppercase tracking-widest2 text-ink/50">
            Location
          </label>
          <input name="author_location" defaultValue={testimonial?.author_location ?? ""} className="input" />
        </div>
      </div>

      <div>
        <label className="mb-1 block font-mono text-[10px] uppercase tracking-widest2 text-ink/50">
          Quote
        </label>
        <textarea name="quote" defaultValue={testimonial?.quote} rows={3} required className="input" />
      </div>

      <div className="grid grid-cols-3 gap-4">
        <div>
          <label className="mb-1 block font-mono text-[10px] uppercase tracking-widest2 text-ink/50">
            Rating (1-5)
          </label>
          <input name="rating" type="number" min={1} max={5} defaultValue={testimonial?.rating ?? 5} className="input" />
        </div>
        <div>
          <label className="mb-1 block font-mono text-[10px] uppercase tracking-widest2 text-ink/50">
            Sort order
          </label>
          <input name="sort_order" type="number" defaultValue={testimonial?.sort_order ?? 0} className="input" />
        </div>
        <div>
          <label className="mb-1 block font-mono text-[10px] uppercase tracking-widest2 text-ink/50">
            Status
          </label>
          <select name="status" defaultValue={testimonial?.status ?? "draft"} className="input">
            <option value="draft">Draft</option>
            <option value="published">Published</option>
          </select>
        </div>
      </div>

      <button
        type="submit"
        className="bg-jade px-6 py-3 font-mono text-xs uppercase tracking-widest2 text-stone-paper hover:bg-jade-deep"
      >
        Save testimonial
      </button>
    </form>
  );
}
