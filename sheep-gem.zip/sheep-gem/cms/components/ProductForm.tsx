import ImageUploader from "./ImageUploader";
import type { Product, Collection } from "@/types";

export default function ProductForm({
  action,
  product,
  collections,
}: {
  action: (formData: FormData) => void;
  product?: Product;
  collections: Collection[];
}) {
  return (
    <form action={action} className="max-w-2xl space-y-5">
      <Field label="Name">
        <input
          name="name"
          defaultValue={product?.name}
          required
          className="input"
        />
      </Field>

      <Field label="Slug (leave blank to auto-generate from name)">
        <input name="slug" defaultValue={product?.slug} className="input" />
      </Field>

      <div className="grid grid-cols-2 gap-4">
        <Field label="Price (USD)">
          <input
            name="price"
            type="number"
            step="0.01"
            defaultValue={product?.price ?? 0}
            required
            className="input"
          />
        </Field>
        <Field label="Collection">
          <select
            name="collection_id"
            defaultValue={product?.collection_id ?? ""}
            className="input"
          >
            <option value="">— None —</option>
            {collections.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
        </Field>
      </div>

      <Field label="Gemstone (e.g. Rose Quartz)">
        <input
          name="gemstone"
          defaultValue={product?.gemstone ?? ""}
          className="input"
        />
      </Field>

      <Field label="Materials">
        <input
          name="materials"
          defaultValue={product?.materials ?? ""}
          className="input"
        />
      </Field>

      <Field label="Meaning (fengshui / spiritual meaning)">
        <textarea
          name="meaning"
          defaultValue={product?.meaning ?? ""}
          rows={3}
          className="input"
        />
      </Field>

      <Field label="Story">
        <textarea
          name="story"
          defaultValue={product?.story ?? ""}
          rows={3}
          className="input"
        />
      </Field>

      <Field label="Description">
        <textarea
          name="description"
          defaultValue={product?.description ?? ""}
          rows={3}
          className="input"
        />
      </Field>

      <Field label="Images">
        <ImageUploader
          name="images"
          defaultValue={product?.images?.join(",")}
        />
      </Field>

      <div className="flex items-center gap-6">
        <label className="flex items-center gap-2 font-mono text-xs uppercase tracking-widest2 text-ink/70">
          <input
            type="checkbox"
            name="featured"
            defaultChecked={product?.featured}
          />
          Featured
        </label>

        <label className="flex items-center gap-2 font-mono text-xs uppercase tracking-widest2 text-ink/70">
          Status
          <select
            name="status"
            defaultValue={product?.status ?? "draft"}
            className="input w-auto"
          >
            <option value="draft">Draft</option>
            <option value="published">Published</option>
          </select>
        </label>
      </div>

      <button
        type="submit"
        className="bg-jade px-6 py-3 font-mono text-xs uppercase tracking-widest2 text-stone-paper hover:bg-jade-deep"
      >
        Save product
      </button>
    </form>
  );
}

function Field({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <div>
      <label className="mb-1 block font-mono text-[10px] uppercase tracking-widest2 text-ink/50">
        {label}
      </label>
      {children}
    </div>
  );
}
