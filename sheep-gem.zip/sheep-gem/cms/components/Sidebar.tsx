import Link from "next/link";
import { signOut } from "@/cms/actions/auth";

const links = [
  { href: "/cms", label: "Dashboard" },
  { href: "/cms/products", label: "Products" },
  { href: "/cms/collections", label: "Collections" },
  { href: "/cms/testimonials", label: "Testimonials" },
  { href: "/cms/faq", label: "FAQ" },
  { href: "/cms/settings", label: "Settings" },
];

export default function Sidebar() {
  return (
    <aside className="flex h-screen w-56 flex-col justify-between border-r border-stone-line bg-stone-paper p-6">
      <div>
        <p className="font-display text-2xl italic text-ink">Sheep Gem</p>
        <p className="font-mono text-[10px] uppercase tracking-widest2 text-ink/40">
          CMS
        </p>
        <nav className="mt-10 flex flex-col gap-1">
          {links.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className="rounded px-3 py-2 font-mono text-xs uppercase tracking-widest2 text-ink/70 hover:bg-stone hover:text-ink"
            >
              {link.label}
            </Link>
          ))}
        </nav>
      </div>
      <form action={signOut}>
        <button
          type="submit"
          className="w-full rounded px-3 py-2 text-left font-mono text-xs uppercase tracking-widest2 text-ink/50 hover:bg-stone hover:text-ink"
        >
          Sign out
        </button>
      </form>
    </aside>
  );
}
