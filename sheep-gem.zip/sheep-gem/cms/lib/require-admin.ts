import "server-only";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";

/**
 * Call at the top of any CMS Server Component or Server Action
 * that isn't already covered by middleware (e.g. Server Actions
 * are not routed through middleware matchers the same way).
 */
export async function requireAdmin() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) redirect("/cms/login");
  return user;
}
