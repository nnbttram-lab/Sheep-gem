"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { requireAdmin } from "@/cms/lib/require-admin";
import { createAdminClient } from "@/lib/supabase/admin";

function slugify(value: string) {
  return value
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
}

function parseProductForm(formData: FormData) {
  const name = String(formData.get("name") ?? "").trim();
  const imagesRaw = String(formData.get("images") ?? "");

  return {
    name,
    slug: slugify(String(formData.get("slug") || name)),
    collection_id: String(formData.get("collection_id") || "") || null,
    price: Number(formData.get("price") || 0),
    meaning: String(formData.get("meaning") || "") || null,
    story: String(formData.get("story") || "") || null,
    description: String(formData.get("description") || "") || null,
    materials: String(formData.get("materials") || "") || null,
    gemstone: String(formData.get("gemstone") || "") || null,
    featured: formData.get("featured") === "on",
    status: String(formData.get("status") || "draft"),
    images: imagesRaw
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean),
  };
}

export async function createProduct(formData: FormData) {
  await requireAdmin();
  const supabase = createAdminClient();
  const payload = parseProductForm(formData);

  const { error } = await supabase.from("products").insert(payload);
  if (error) throw new Error(error.message);

  revalidatePath("/cms/products");
  revalidatePath("/");
  redirect("/cms/products");
}

export async function updateProduct(id: string, formData: FormData) {
  await requireAdmin();
  const supabase = createAdminClient();
  const payload = parseProductForm(formData);

  const { error } = await supabase
    .from("products")
    .update(payload)
    .eq("id", id);
  if (error) throw new Error(error.message);

  revalidatePath("/cms/products");
  revalidatePath("/");
  redirect("/cms/products");
}

export async function deleteProduct(id: string) {
  await requireAdmin();
  const supabase = createAdminClient();

  const { error } = await supabase.from("products").delete().eq("id", id);
  if (error) throw new Error(error.message);

  revalidatePath("/cms/products");
  revalidatePath("/");
}
