"use server";

import { revalidatePath } from "next/cache";
import { requireAdmin } from "@/cms/lib/require-admin";
import { createAdminClient } from "@/lib/supabase/admin";

export async function updateSiteSettings(formData: FormData) {
  await requireAdmin();
  const supabase = createAdminClient();

  const value = {
    brand_name: String(formData.get("brand_name") ?? "").trim(),
    tagline_en: String(formData.get("tagline_en") ?? "").trim(),
    tagline_vi: String(formData.get("tagline_vi") ?? "").trim(),
  };

  const { error } = await supabase
    .from("settings")
    .upsert({ key: "site", value }, { onConflict: "key" });
  if (error) throw new Error(error.message);

  revalidatePath("/cms/settings");
  revalidatePath("/");
}
