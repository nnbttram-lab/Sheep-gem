"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { requireAdmin } from "@/cms/lib/require-admin";
import { createAdminClient } from "@/lib/supabase/admin";

function parseForm(formData: FormData) {
  return {
    question: String(formData.get("question") ?? "").trim(),
    answer: String(formData.get("answer") ?? "").trim(),
    sort_order: Number(formData.get("sort_order") || 0),
    status: String(formData.get("status") || "draft"),
  };
}

export async function createFaq(formData: FormData) {
  await requireAdmin();
  const supabase = createAdminClient();
  const { error } = await supabase.from("faq").insert(parseForm(formData));
  if (error) throw new Error(error.message);

  revalidatePath("/cms/faq");
  revalidatePath("/");
  redirect("/cms/faq");
}

export async function updateFaq(id: string, formData: FormData) {
  await requireAdmin();
  const supabase = createAdminClient();
  const { error } = await supabase
    .from("faq")
    .update(parseForm(formData))
    .eq("id", id);
  if (error) throw new Error(error.message);

  revalidatePath("/cms/faq");
  revalidatePath("/");
  redirect("/cms/faq");
}

export async function deleteFaq(id: string) {
  await requireAdmin();
  const supabase = createAdminClient();
  const { error } = await supabase.from("faq").delete().eq("id", id);
  if (error) throw new Error(error.message);

  revalidatePath("/cms/faq");
  revalidatePath("/");
}
