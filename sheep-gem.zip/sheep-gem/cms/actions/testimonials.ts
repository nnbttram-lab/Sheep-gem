"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { requireAdmin } from "@/cms/lib/require-admin";
import { createAdminClient } from "@/lib/supabase/admin";

function parseForm(formData: FormData) {
  return {
    author_name: String(formData.get("author_name") ?? "").trim(),
    author_location: String(formData.get("author_location") || "") || null,
    quote: String(formData.get("quote") ?? "").trim(),
    rating: Number(formData.get("rating") || 5),
    sort_order: Number(formData.get("sort_order") || 0),
    status: String(formData.get("status") || "draft"),
  };
}

export async function createTestimonial(formData: FormData) {
  await requireAdmin();
  const supabase = createAdminClient();
  const { error } = await supabase.from("testimonials").insert(parseForm(formData));
  if (error) throw new Error(error.message);

  revalidatePath("/cms/testimonials");
  revalidatePath("/");
  redirect("/cms/testimonials");
}

export async function updateTestimonial(id: string, formData: FormData) {
  await requireAdmin();
  const supabase = createAdminClient();
  const { error } = await supabase
    .from("testimonials")
    .update(parseForm(formData))
    .eq("id", id);
  if (error) throw new Error(error.message);

  revalidatePath("/cms/testimonials");
  revalidatePath("/");
  redirect("/cms/testimonials");
}

export async function deleteTestimonial(id: string) {
  await requireAdmin();
  const supabase = createAdminClient();
  const { error } = await supabase.from("testimonials").delete().eq("id", id);
  if (error) throw new Error(error.message);

  revalidatePath("/cms/testimonials");
  revalidatePath("/");
}
