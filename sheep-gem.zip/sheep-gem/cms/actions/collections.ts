"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { requireAdmin } from "@/cms/lib/require-admin";
import { createAdminClient } from "@/lib/supabase/admin";

function slugify(value: string) {
  return value
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
}

function parseForm(formData: FormData) {
  const name = String(formData.get("name") ?? "").trim();
  return {
    name,
    slug: slugify(String(formData.get("slug") || name)),
    description: String(formData.get("description") || "") || null,
    cover_image: String(formData.get("cover_image") || "") || null,
    sort_order: Number(formData.get("sort_order") || 0),
    status: String(formData.get("status") || "draft"),
  };
}

export async function createCollection(formData: FormData) {
  await requireAdmin();
  const supabase = createAdminClient();
  const { error } = await supabase
    .from("collections")
    .insert(parseForm(formData));
  if (error) throw new Error(error.message);

  revalidatePath("/cms/collections");
  revalidatePath("/");
  redirect("/cms/collections");
}

export async function updateCollection(id: string, formData: FormData) {
  await requireAdmin();
  const supabase = createAdminClient();
  const { error } = await supabase
    .from("collections")
    .update(parseForm(formData))
    .eq("id", id);
  if (error) throw new Error(error.message);

  revalidatePath("/cms/collections");
  revalidatePath("/");
  redirect("/cms/collections");
}

export async function deleteCollection(id: string) {
  await requireAdmin();
  const supabase = createAdminClient();
  const { error } = await supabase.from("collections").delete().eq("id", id);
  if (error) throw new Error(error.message);

  revalidatePath("/cms/collections");
  revalidatePath("/");
}
