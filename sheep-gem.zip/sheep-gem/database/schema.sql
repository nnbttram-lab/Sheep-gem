-- Sheep Gem — Database Schema
-- Run this in the Supabase SQL Editor (Project > SQL Editor > New query)

create extension if not exists "uuid-ossp";

-- ─── collections ─────────────────────────────────────────
create table if not exists collections (
  id uuid primary key default uuid_generate_v4(),
  slug text unique not null,
  name text not null,
  description text,
  cover_image text,
  sort_order int default 0,
  status text not null default 'draft' check (status in ('draft', 'published')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ─── products ────────────────────────────────────────────
create table if not exists products (
  id uuid primary key default uuid_generate_v4(),
  slug text unique not null,
  name text not null,
  collection_id uuid references collections(id) on delete set null,
  price numeric(10, 2) not null default 0,
  meaning text,          -- fengshui / spiritual meaning
  story text,            -- origin story / narrative
  description text,      -- practical description
  materials text,
  gemstone text,         -- e.g. "Rose Quartz", "Black Obsidian"
  featured boolean not null default false,
  status text not null default 'draft' check (status in ('draft', 'published')),
  images jsonb not null default '[]', -- array of storage URLs
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists idx_products_collection on products(collection_id);
create index if not exists idx_products_status on products(status);
create index if not exists idx_products_featured on products(featured);

-- ─── testimonials ────────────────────────────────────────
create table if not exists testimonials (
  id uuid primary key default uuid_generate_v4(),
  author_name text not null,
  author_location text,
  quote text not null,
  rating int check (rating between 1 and 5),
  avatar_url text,
  status text not null default 'draft' check (status in ('draft', 'published')),
  sort_order int default 0,
  created_at timestamptz not null default now()
);

-- ─── faq ─────────────────────────────────────────────────
create table if not exists faq (
  id uuid primary key default uuid_generate_v4(),
  question text not null,
  answer text not null,
  sort_order int default 0,
  status text not null default 'draft' check (status in ('draft', 'published')),
  created_at timestamptz not null default now()
);

-- ─── settings (singleton key/value store) ───────────────
create table if not exists settings (
  key text primary key,
  value jsonb not null,
  updated_at timestamptz not null default now()
);

-- ─── media (Supabase Storage references) ────────────────
create table if not exists media (
  id uuid primary key default uuid_generate_v4(),
  file_path text not null,      -- path inside the storage bucket
  public_url text not null,
  alt_text text,
  created_at timestamptz not null default now()
);

-- Phase 2 groundwork (kept empty/unused for now so the
-- future Knowledge Hub / blog doesn't require a migration later)
create table if not exists articles (
  id uuid primary key default uuid_generate_v4(),
  slug text unique not null,
  title text not null,
  excerpt text,
  body text,
  cover_image text,
  tags text[] default '{}',
  status text not null default 'draft' check (status in ('draft', 'published')),
  published_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ─── updated_at triggers ─────────────────────────────────
create or replace function set_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

drop trigger if exists trg_products_updated_at on products;
create trigger trg_products_updated_at before update on products
  for each row execute function set_updated_at();

drop trigger if exists trg_collections_updated_at on collections;
create trigger trg_collections_updated_at before update on collections
  for each row execute function set_updated_at();

drop trigger if exists trg_articles_updated_at on articles;
create trigger trg_articles_updated_at before update on articles
  for each row execute function set_updated_at();

-- ─── Row Level Security ──────────────────────────────────
-- Public (anon) can only READ published content.
-- All writes go through the service_role key from the CMS server routes.

alter table collections enable row level security;
alter table products enable row level security;
alter table testimonials enable row level security;
alter table faq enable row level security;
alter table settings enable row level security;
alter table media enable row level security;
alter table articles enable row level security;

create policy "public read published collections" on collections
  for select using (status = 'published');

create policy "public read published products" on products
  for select using (status = 'published');

create policy "public read published testimonials" on testimonials
  for select using (status = 'published');

create policy "public read published faq" on faq
  for select using (status = 'published');

create policy "public read settings" on settings
  for select using (true);

create policy "public read published articles" on articles
  for select using (status = 'published');

-- media has no public policy — only accessed via service_role in the CMS.

-- Seed sensible defaults for settings
insert into settings (key, value) values
  ('site', '{"brand_name": "Sheep Gem", "tagline_en": "Find the stone that finds you.", "tagline_vi": "Tìm viên đá tìm thấy bạn."}')
on conflict (key) do nothing;
