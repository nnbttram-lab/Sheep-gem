import { createServerClient } from "@supabase/ssr";
import type { CookieOptions } from "@supabase/ssr";
import { NextResponse, type NextRequest } from "next/server";
import { LOCALE_COOKIE, isLocale } from "@/lib/i18n/locales";

export async function middleware(request: NextRequest) {
  let response = NextResponse.next({ request });
  const isCmsRoute = request.nextUrl.pathname.startsWith("/cms");
  const isLoginRoute = request.nextUrl.pathname === "/cms/login";

  if (isCmsRoute) {
    const supabase = createServerClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
      {
        cookies: {
          getAll() {
            return request.cookies.getAll();
          },
          setAll(
            cookiesToSet: { name: string; value: string; options: CookieOptions }[]
          ) {
            cookiesToSet.forEach(({ name, value }) =>
              request.cookies.set(name, value)
            );
            response = NextResponse.next({ request });
            cookiesToSet.forEach(({ name, value, options }) =>
              response.cookies.set(name, value, options)
            );
          },
        },
      }
    );

    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (!isLoginRoute && !user) {
      return NextResponse.redirect(new URL("/cms/login", request.url));
    }

    if (isLoginRoute && user) {
      return NextResponse.redirect(new URL("/cms", request.url));
    }

    // Admin tool stays English-only — no locale detection needed.
    return response;
  }

  // ─── Locale detection for public pages ───
  const langOverride = request.nextUrl.searchParams.get("lang");

  if (isLocale(langOverride)) {
    // Explicit ?lang= wins and is remembered — also useful for testing
    // the Vietnamese version locally without a Vietnamese IP/VPN.
    response.cookies.set(LOCALE_COOKIE, langOverride, {
      path: "/",
      maxAge: 60 * 60 * 24 * 365,
    });
  } else if (!request.cookies.get(LOCALE_COOKIE)) {
    // First visit, no saved preference: default to Vietnamese for
    // visitors on a Vietnamese IP (Vercel sets this header at the
    // edge), otherwise English.
    const country =
      request.headers.get("x-vercel-ip-country") ?? request.geo?.country ?? "";
    const detected = country === "VN" ? "vi" : "en";
    response.cookies.set(LOCALE_COOKIE, detected, {
      path: "/",
      maxAge: 60 * 60 * 24 * 365,
    });
  }

  return response;
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico).*)"],
};
