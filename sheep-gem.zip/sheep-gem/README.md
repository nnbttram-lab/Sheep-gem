# Sheep Gem — Landing Page + CMS

Phase 1 MVP: Next.js App Router site backed by a custom Supabase-powered
admin dashboard. Built from `Sheep_Gem_Engineering_Handbook_v1`.

## Stack
- Next.js 14 (App Router) + TypeScript
- Tailwind CSS + Framer Motion
- Supabase (Postgres + Storage + Auth)
- Deploy target: Vercel

## 1. Install

```bash
npm install
```

## 2. Environment variables

`.env.local` is already filled in with your Supabase project's URL and keys.
If you ever rotate keys, update:

```
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=      # server-only, never exposed to the browser

NEXT_PUBLIC_INSTAGRAM_HANDLE=   # for the "Talk with Sheep" CTA
NEXT_PUBLIC_MESSENGER_PAGE=
```

## 3. Set up the database

In your Supabase project: **SQL Editor → New query**, paste the contents of
`database/schema.sql`, and run it. This creates all 7 tables (`products`,
`collections`, `testimonials`, `faq`, `settings`, `media`, plus `articles`
for the future Knowledge Hub), indexes, `updated_at` triggers, and
Row Level Security policies (public visitors can only read `published`
rows; all writes go through the CMS using the service_role key).

## 4. Set up Storage

**Storage → New bucket** → name it `media` → toggle **Public bucket** on.
This is where product photos and collection covers are uploaded from the
CMS.

## 5. Create your admin login

**Authentication → Users → Add user** → enter your email + a password.
That's your CMS login — there's no public sign-up form, by design.

## 6. Run it

```bash
npm run dev
```
- Public site: http://localhost:3000
- CMS: http://localhost:3000/cms/login

## 7. Add your first content

Nothing shows on the homepage until you publish something:
1. Log into `/cms`
2. Create a **Collection** (status: Published)
3. Create a **Product** inside it, upload an image, mark it **Featured**
   and **Published**
4. Add a few **Testimonials** and **FAQ** entries, also Published
5. Set your **Settings** tagline

Refresh the homepage — it's now pulling live from your CMS.

## 8. Deploy

Push this to a GitHub repo, import it in Vercel, and add the same
environment variables from `.env.local` in the Vercel project settings.
Vercel handles the build and hosting; Supabase stays as-is.

## Project structure

```
app/            → routes (public pages + /cms admin routes)
components/     → public-site UI components
cms/            → admin-only components, server actions, auth guard
lib/            → Supabase clients (browser / server / admin) + helpers
services/       → typed read functions used by public pages
types/          → shared TypeScript types
database/       → schema.sql (run once in Supabase)
```

## Bilingual site (English / Vietnamese)

The storefront UI (nav, buttons, section headers, About/Philosophy copy)
is available in English and Vietnamese:

- **Auto-detection**: on Vercel, a first-time visitor from a Vietnamese IP
  sees Vietnamese by default; everyone else sees English. This relies on
  Vercel's edge geolocation header, so it only works once deployed.
- **Manual switch**: the EN / VI toggle in the nav lets any visitor
  override this, and their choice is remembered (cookie, 1 year).
- **Local testing**: since your dev machine isn't on a Vietnamese IP, add
  `?lang=vi` to any URL (e.g. `localhost:3000/?lang=vi`) to force the
  Vietnamese version and save it as your preference.

**What's translated vs. not:** the site chrome above is fully bilingual.
Content you type into the CMS — product names, meanings, stories,
testimonials, FAQ answers, and the homepage tagline (which has separate
English/Vietnamese fields in Settings) — displays in whatever language
you wrote it in. Making product-level content itself bilingual (e.g. two
versions of a product's "meaning" field) is a bigger schema change, and
lines up with "Localization" in the handbook's Phase 2 roadmap.

## Notes on the "Talk with Sheep" CTA

Instagram is the primary channel; Facebook Messenger is the fallback if a
visitor can't reach Sheep on Instagram. Instagram doesn't support
prefilled DM text via URL, so the message is shown on the page for the
visitor to copy into the chat. Facebook Messenger *does* support
prefilled text via `m.me/yourpage?text=`, which is wired up automatically.
Both links and the message text live in `lib/consultation.ts`.

## What's intentionally not built yet (Phase 2, per the handbook)

Blog / Knowledge Hub, AI recommendations, user accounts, journey tracking,
localization. The `articles` table already exists in the schema so the
Knowledge Hub can be added later without a migration — see the next
message for that roadmap.
