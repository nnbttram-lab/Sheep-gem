export type ContentStatus = "draft" | "published";

export interface Collection {
  id: string;
  slug: string;
  name: string;
  description: string | null;
  cover_image: string | null;
  sort_order: number;
  status: ContentStatus;
  created_at: string;
  updated_at: string;
}

export interface Product {
  id: string;
  slug: string;
  name: string;
  collection_id: string | null;
  price: number;
  meaning: string | null;
  story: string | null;
  description: string | null;
  materials: string | null;
  gemstone: string | null;
  featured: boolean;
  status: ContentStatus;
  images: string[];
  created_at: string;
  updated_at: string;
  collection?: Collection | null;
}

export interface Testimonial {
  id: string;
  author_name: string;
  author_location: string | null;
  quote: string;
  rating: number | null;
  avatar_url: string | null;
  status: ContentStatus;
  sort_order: number;
  created_at: string;
}

export interface FaqItem {
  id: string;
  question: string;
  answer: string;
  sort_order: number;
  status: ContentStatus;
  created_at: string;
}

export interface SiteSettings {
  brand_name: string;
  tagline_en: string;
  tagline_vi: string;
  [key: string]: unknown;
}
