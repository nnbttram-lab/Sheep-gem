import "server-only";
import { createClient as createSupabaseClient } from "@supabase/supabase-js";

/**
 * Admin client using the service_role key.
 * SERVER-ONLY — never import this into a Client Component.
 * Bypasses RLS entirely, so every call site must apply its
 * own authorization checks (see cms/lib/require-admin.ts).
 */
export function createAdminClient() {
  return createSupabaseClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    { auth: { persistSession: false } }
  );
}
