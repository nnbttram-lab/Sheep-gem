import type { Locale } from "./locales";

export const dictionaries = {
  en: {
    nav: {
      collections: "Collections",
      about: "About",
      faq: "FAQ",
      talkWithSheep: "Talk with Sheep",
    },
    hero: {
      eyebrow: "Est. for those who seek balance",
      subtext:
        "Every gemstone is chosen for what it carries, not just how it looks — matched to your intention, your birth elements, and the balance you're seeking.",
      exploreCollections: "Explore Collections",
      talkWithSheep: "Talk with Sheep",
    },
    about: {
      eyebrow: "The name",
      title: 'Why "Sheep"',
      body: "The sheep is a quiet guide — steady, gentle, and unbothered by noise. We chose the name because that's how we believe choosing a stone should feel: unhurried, personal, led by instinct rather than trend. Every piece we carry has been selected the same way — slowly, and with intention.",
    },
    philosophy: {
      eyebrow: "Our philosophy",
      title: "Five elements, one balance",
      body: "Fengshui teaches that everything — a room, a life, a person — is shaped by five elements in motion. We map every stone in our collection to the element it carries, so you can choose based on what you actually need more of.",
      elements: [
        { name: "Wood", stone: "Green Jade", trait: "Growth & renewal" },
        { name: "Fire", stone: "Carnelian", trait: "Passion & courage" },
        { name: "Earth", stone: "Tiger's Eye", trait: "Stability & grounding" },
        { name: "Metal", stone: "Clear Quartz", trait: "Clarity & precision" },
        { name: "Water", stone: "Lapis Lazuli", trait: "Intuition & flow" },
      ],
    },
    collectionsSection: {
      eyebrow: "Browse by",
      title: "Collections",
      viewAll: "View all →",
      empty: "Collections will appear here once published from the CMS.",
    },
    featured: {
      eyebrow: "Hand-selected",
      title: "Featured stones",
    },
    consultation: {
      eyebrow: "Not sure which stone",
      title: "Talk with Sheep",
      subtext:
        "Send a message and we'll help you find the stone that matches what you're carrying right now.",
      yourMessage: "Your message",
      instagramBtn: "Message on Instagram",
      facebookBtn: "Can't reach Instagram? Message on Facebook",
    },
    testimonials: {
      eyebrow: "Words from the flock",
      title: "What people found",
    },
    faq: {
      eyebrow: "Good to know",
      title: "Frequently asked",
    },
    product: {
      gemstone: "Gemstone",
      materials: "Materials",
      meaning: "Meaning",
      story: "Story",
      description: "Description",
      noImage: "No image",
      view: "View →",
    },
    collectionsPage: {
      eyebrow: "Every stone, its place",
      title: "Collections",
    },
    aboutPage: {
      eyebrow: "Our story",
      title: "About Sheep Gem",
    },
  },
  vi: {
    nav: {
      collections: "Bộ sưu tập",
      about: "Giới thiệu",
      faq: "Câu hỏi thường gặp",
      talkWithSheep: "Trò chuyện với Cừu",
    },
    hero: {
      eyebrow: "Dành cho những ai tìm kiếm sự cân bằng",
      subtext:
        "Mỗi viên đá được chọn vì ý nghĩa nó mang theo, không chỉ vì vẻ ngoài — phù hợp với mong muốn, mệnh và sự cân bằng bạn đang tìm kiếm.",
      exploreCollections: "Khám phá bộ sưu tập",
      talkWithSheep: "Trò chuyện với Cừu",
    },
    about: {
      eyebrow: "Về cái tên",
      title: 'Vì sao là "Cừu"',
      body: "Cừu là một người dẫn đường thầm lặng — điềm tĩnh, nhẹ nhàng và không bị xao động bởi ồn ào. Chúng tôi chọn cái tên này vì đó chính là cách chúng tôi tin việc chọn đá nên diễn ra: từ tốn, riêng tư, dẫn dắt bởi trực giác hơn là xu hướng. Mỗi món đồ chúng tôi có đều được chọn theo cách đó — chậm rãi và có chủ đích.",
    },
    philosophy: {
      eyebrow: "Triết lý của chúng tôi",
      title: "Ngũ hành, một sự cân bằng",
      body: "Phong thủy dạy rằng mọi thứ — một căn phòng, một cuộc đời, một con người — đều được định hình bởi ngũ hành luôn vận động. Chúng tôi gắn mỗi viên đá trong bộ sưu tập với hành mà nó mang, để bạn có thể chọn dựa trên điều mình thực sự cần thêm.",
      elements: [
        { name: "Mộc", stone: "Ngọc bích xanh", trait: "Sinh trưởng & đổi mới" },
        { name: "Hỏa", stone: "Mã não đỏ", trait: "Đam mê & can đảm" },
        { name: "Thổ", stone: "Mắt hổ", trait: "Ổn định & vững vàng" },
        { name: "Kim", stone: "Thạch anh trắng", trait: "Sáng suốt & chính xác" },
        { name: "Thủy", stone: "Lưu ly (Lapis Lazuli)", trait: "Trực giác & lưu chuyển" },
      ],
    },
    collectionsSection: {
      eyebrow: "Khám phá theo",
      title: "Bộ sưu tập",
      viewAll: "Xem tất cả →",
      empty: "Bộ sưu tập sẽ hiển thị ở đây sau khi được đăng từ CMS.",
    },
    featured: {
      eyebrow: "Được tuyển chọn",
      title: "Đá nổi bật",
    },
    consultation: {
      eyebrow: "Chưa biết chọn đá nào",
      title: "Trò chuyện với Cừu",
      subtext:
        "Nhắn tin và chúng tôi sẽ giúp bạn tìm viên đá phù hợp với những gì bạn đang mang theo.",
      yourMessage: "Tin nhắn của bạn",
      instagramBtn: "Nhắn tin qua Instagram",
      facebookBtn: "Không vào được Instagram? Nhắn qua Facebook",
    },
    testimonials: {
      eyebrow: "Lời từ khách hàng",
      title: "Những gì mọi người đã tìm thấy",
    },
    faq: {
      eyebrow: "Điều nên biết",
      title: "Câu hỏi thường gặp",
    },
    product: {
      gemstone: "Loại đá",
      materials: "Chất liệu",
      meaning: "Ý nghĩa",
      story: "Câu chuyện",
      description: "Mô tả",
      noImage: "Chưa có hình",
      view: "Xem →",
    },
    collectionsPage: {
      eyebrow: "Mỗi viên đá, một vị trí",
      title: "Bộ sưu tập",
    },
    aboutPage: {
      eyebrow: "Câu chuyện của chúng tôi",
      title: "Về Sheep Gem",
    },
  },
} satisfies Record<Locale, unknown>;

export type Dictionary = (typeof dictionaries)["en"];

export function getDictionary(locale: Locale): Dictionary {
  return dictionaries[locale];
}
