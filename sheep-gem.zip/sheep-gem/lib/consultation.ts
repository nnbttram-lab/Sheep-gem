/**
 * Builds "Talk with Sheep" deep links, per handbook §9.
 * Instagram is the primary channel; Facebook Messenger is the
 * fallback if the customer can't reach Sheep on Instagram.
 *
 * Set NEXT_PUBLIC_INSTAGRAM_HANDLE and NEXT_PUBLIC_MESSENGER_PAGE
 * in .env.local to your real handles.
 */

function buildMessage(productName?: string) {
  const base = "Cừu có thể giúp mình tìm đá phù hợp với câu chuyện của mình được không?";
  return productName ? `${base} Mình đang quan tâm đến ${productName}.` : base;
}

export function getInstagramLink(productName?: string) {
  const handle = process.env.NEXT_PUBLIC_INSTAGRAM_HANDLE || "sheep.gem";
  // Instagram DMs don't support prefilled text via URL. ig.me/m/ deep
  // links straight into a new DM thread with Sheep; the message text
  // is shown next to the button for the visitor to copy.
  return `https://ig.me/m/${handle}`;
}

export function getInstagramProfileLink() {
  const handle = process.env.NEXT_PUBLIC_INSTAGRAM_HANDLE || "sheep.gem";
  return `https://www.instagram.com/${handle}/`;
}

export function getMessengerLink(productName?: string) {
  const page = process.env.NEXT_PUBLIC_MESSENGER_PAGE || "sheep.gem";
  const text = encodeURIComponent(buildMessage(productName));
  return `https://m.me/${page}?text=${text}`;
}

export function getPrefilledMessage(productName?: string) {
  return buildMessage(productName);
}
