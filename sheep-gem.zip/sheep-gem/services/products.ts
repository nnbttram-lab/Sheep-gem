import { createClient } from "@/lib/supabase/server";
import type { Product } from "@/types";

/** All published products, newest first. */
export async function getPublishedProducts(): Promise<Product[]> {
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("products")
    .select("*, collection:collections(*)")
    .eq("status", "published")
    .order("created_at", { ascending: false });

  if (error) throw error;
  return data ?? [];
}

/** Featured products for the homepage grid. */
export async function getFeaturedProducts(limit = 6): Promise<Product[]> {
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("products")
    .select("*, collection:collections(*)")
    .eq("status", "published")
    .eq("featured", true)
    .order("created_at", { ascending: false })
    .limit(limit);

  if (error) throw error;
  return data ?? [];
}

/** Single product by slug, for /product/[slug]. */
export async function getProductBySlug(slug: string): Promise<Product | null> {
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("products")
    .select("*, collection:collections(*)")
    .eq("slug", slug)
    .eq("status", "published")
    .maybeSingle();

  if (error) throw error;
  return data;
}

/** Products within a given collection slug. */
export async function getProductsByCollection(
  collectionSlug: string
): Promise<Product[]> {
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("products")
    .select("*, collection:collections!inner(*)")
    .eq("status", "published")
    .eq("collection.slug", collectionSlug)
    .order("created_at", { ascending: false });

  if (error) throw error;
  return data ?? [];
}
