import { createClient } from "@/lib/supabase/server";
import type { SiteSettings } from "@/types";
import type { Locale } from "@/lib/i18n/locales";

const DEFAULT_SITE_SETTINGS: SiteSettings = {
  brand_name: "Sheep Gem",
  tagline_en: "Find the stone that finds you.",
  tagline_vi: "Tìm viên đá tìm thấy bạn.",
};

export async function getSiteSettings(): Promise<SiteSettings> {
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("settings")
    .select("value")
    .eq("key", "site")
    .maybeSingle();

  if (error) throw error;
  return { ...DEFAULT_SITE_SETTINGS, ...(data?.value as object) };
}

export function getTagline(settings: SiteSettings, locale: Locale): string {
  return locale === "vi" ? settings.tagline_vi : settings.tagline_en;
}
