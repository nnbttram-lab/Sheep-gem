import { createClient } from "@/lib/supabase/server";
import type { FaqItem } from "@/types";

export async function getPublishedFaq(): Promise<FaqItem[]> {
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("faq")
    .select("*")
    .eq("status", "published")
    .order("sort_order", { ascending: true });

  if (error) throw error;
  return data ?? [];
}
